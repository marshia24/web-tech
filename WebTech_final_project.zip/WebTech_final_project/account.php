<?php

    include "includes/db_connect.inc.php";
    session_start();
    $uName = $uType = $uPic = $uflatno = "";

    if(!isset($_SESSION["username"])){
        header("Location: login.php");
    }
    $uName=$_SESSION["username"];

    $sql = "SELECT u_name , u_pic FROM usr WHERE username = '$uName'";
    $result = mysqli_query($conn, $sql);
    $rowCount = mysqli_num_rows($result);
    while($row = mysqli_fetch_assoc($result)){
        $uType = $row['u_name'];
        $uPic = $row['u_pic'];
    }
    $rdelete = $message = "" ;

    if($_SERVER["REQUEST_METHOD"] == "POST"){
	
        if(!empty($_POST['delete'])){
            $rdelete = mysqli_real_escape_string($conn, $_POST['delete']);
        }
    
        $sqlUserCheck = "DELETE FROM usr WHERE u_id=$rdelete";
        if ($conn->query($sqlUserCheck) == TRUE) {
            echo "<script>alert('Record deleted successfully')</script>";
          }
    }
    ?>
   
<html>
    <head>
        <title>Welcome</title>
        <link rel="stylesheet" href="css/account.css">
    </head>
    
    <body>
        <section class="header">
            <div>
                <div class="dp">
                    <img src="data:image/jpeg;base64,<?php echo base64_encode($uPic) ; ?>" style="width:150px">
                </div>
                
                <a class="una" href="account.php"><?php echo $uName; ?></a><br>
            </div>
            <div>
                <div class="member_dropdown">
                    <button class="Mbutton">Users></button>
                    <div class="member-content">
                        <button class="MCbutton" onclick="member_list()">Managers</button>
                        <button class="MCbutton" onclick="add_member()">Customers</button>
                        <button class="MCbutton" onclick="window.location.href = 'adduser.php';">ADD User</button>
                    </div>
                </div>

                <div class="servant_dropdown">
                    <button class="Sbutton">Appartments></button>
                    <div class="servant-content">
                        <button class="SCbutton" onclick="servant_list()">Appartments List</button>
                        <button class="SCbutton" onclick="window.location.href = 'addapart.php';">insert Appartment</button>
                    </div>
                </div>
            </div>
        </section>

        <Section class="main">
            <div class="logout">
                <a class="lg" href="logout.php">Logout</a>
			</div>
        </section>

        <section class="member_list_border" id="member_list_border">
            <h1 align="center"><u>Manager</u></h1>
            <style>
                table,td,td {
                    border: 1px solid black;
                }
                table {
                    border-collapse:collapse;
                    width:100%;
                }
                th{
                    height:50px;
                }
            </style>
           
            <table >
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone_Number</th>
                </tr>
                <?php
                    include "includes/db_connect.inc.php";
                    $sql = "SELECT * FROM usr where u_type='admin'";
                    $result = mysqli_query($conn, $sql);
                    if ($result-> num_rows >0){
                    while($row = $result-> fetch_assoc()){
                        echo"<tr><td>".$row["u_id"]."</td><td>".$row["u_name"]."</td><td>".$row["u_email"]."</td><td>".$row["u_phoneno"]."</td><td><form action="."account.php"." method="."post".">
                        <button type="."submit"." name="."delete"." class="."Delete"." value=".$row["u_id"].">Delete</button><br></form></td>
                        <td><form action="."updateuser.php"." method="."get"."><button type="."submit"." name="."uuid"." value=".$row["u_id"].">Update</button><br></form></td></tr>";
                    }
                    
                    }

                ?>
            </table>
            
            
        </section>
        <section class="add_member_border" id="add_member_border">
            <h1 align="center"><u>Manager</u></h1>
            <style>
                table,td,td {
                    border: 1px solid black;
                }
                table {
                    border-collapse:collapse;
                    width:100%;
                }
                th{
                    height:50px;
                }
            </style>
           
            <table >
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone_Number</th>
                </tr>
                <?php
                    include "includes/db_connect.inc.php";
                    $sql = "SELECT * FROM usr where u_type='customer'";
                    $result = mysqli_query($conn, $sql);
                    if ($result-> num_rows >0){
                    while($row = $result-> fetch_assoc()){
                        echo"<tr><td>".$row["u_id"]."</td><td>".$row["u_name"]."</td><td>".$row["u_email"]."</td><td>".$row["u_phoneno"]."</td><td><form action="."account.php"." method="."post".">
                        <button type="."submit"." name="."delete"." class="."Delete"." value=".$row["u_id"].">Delete</button><br></form></td>
                        <td><form action="."updateuser.php"." method="."get"."><button type="."submit"." name="."uuid"." value=".$row["u_id"].">Update</button><br></form></td></tr>";
                    }
                    }

                ?>
            </table>
        </section>



        <section class="servant_list_border" id="servant_list_border">
            <style>
                .servant_list_border {
                    width: 1153px;
                    min-height: 692px;
                    margin-left: 0px;
                    margin-top: 5px;
                    background-color: whitesmoke;
                    border-style: solid;
                    border-color: silver;
                    float: right;
                    display: block;
                }
            </style>
            <h1 align="center"><u>Appartments</u></h1>
            <style>
                table,td,td {
                    border: 1px solid black;
                }
                table {
                    border-collapse:collapse;
                    width:100%;
                }
                th{
                    height:50px;
                }
            </style>
           
            <table >
                <tr>
                    <th>ID</th>
                    <th>Number</th>
                    <th>Floor no.</th>
                    <th>No. of room</th>
                    <th>Description</th>
                    <th>picture</th>
                </tr>
                <?php
                    include "includes/db_connect.inc.php";
                    $sql = "SELECT * FROM apartment";
                    $result = mysqli_query($conn, $sql);
                    if ($result-> num_rows >0){
                    while($row = $result-> fetch_assoc()){
                        echo"<tr><td>".$row["a_id"]."</td><td>".$row["a_no"]."</td><td>".$row["floor_no"]."</td><td>".$row["no_of_room"]."</td><td>".$row["description"]."</td><td></td>
                        <td><form action="."updateapart.php"." method="."get"."><button type="."submit"." name="."uuid"." value=".$row["a_id"].">Update</button><br></form></td></tr>";
                    }
                    
                    }

                ?>
            </table>
            
            
        </section>

        <script>
            function member_list() {

                var member_list_border = document.getElementById("member_list_border");
                var add_member_border = document.getElementById("add_member_border");
                var member_exitentry_border = document.getElementById("member_exitentry_border");
                var servant_list_border = document.getElementById("servant_list_border");

            
                    member_list_border.style.display = "block";
                    add_member_border.style.display = "none";
                    member_exitentry_border.style.display = "none";
                    servant_list_border.style.display = "none";
            
            }
            function add_member() {

                    var member_list_border = document.getElementById("member_list_border");
                    var add_member_border = document.getElementById("add_member_border");
                    var member_exitentry_border = document.getElementById("member_exitentry_border");
                    var servant_list_border = document.getElementById("servant_list_border");

                    member_list_border.style.display = "none";
                    add_member_border.style.display = "block";
                    member_exitentry_border.style.display = "none";
                    servant_list_border.style.display = "none";

            }
            function member_exitentry() {

                    var member_list_border = document.getElementById("member_list_border");
                    var add_member_border = document.getElementById("add_member_border");
                    var member_exitentry_border = document.getElementById("member_exitentry_border");
                    var servant_list_border = document.getElementById("servant_list_border");


                    member_list_border.style.display = "none";
                    add_member_border.style.display = "none";
                    member_exitentry_border.style.display = "block";
                    servant_list_border.style.display = "none";

            }
            function servant_list() {

                    var member_list_border = document.getElementById("member_list_border");
                    var add_member_border = document.getElementById("add_member_border");
                    var member_exitentry_border = document.getElementById("member_exitentry_border");
                    var servant_list_border = document.getElementById("servant_list_border");


                    member_list_border.style.display = "none";
                    add_member_border.style.display = "none";
                    member_exitentry_border.style.display = "none";
                    servant_list_border.style.display = "block";

            }
        </script>

    </body>
</html>
