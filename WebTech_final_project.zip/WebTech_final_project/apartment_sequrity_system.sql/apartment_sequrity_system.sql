-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2020 at 09:04 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apartment_sequrity_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `apartment`
--

CREATE TABLE `apartment` (
  `a_id` int(11) NOT NULL,
  `a_no` varchar(255) DEFAULT NULL,
  `floor_no` varchar(255) DEFAULT NULL,
  `no_of_room` int(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `a_pic` blob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `apartment`
--

INSERT INTO `apartment` (`a_id`, `a_no`, `floor_no`, `no_of_room`, `description`, `a_pic`) VALUES
(1, '4d', '4', 1234, '342424234', 0x50696e7943726561746f72735f3633373334303038353131363535363033332e6a7067),
(2, '1', '1', 1, '1', 0x50696e7943726561746f72735f3633373334303038323937393539383432312e6a7067);

-- --------------------------------------------------------

--
-- Table structure for table `usr`
--

CREATE TABLE `usr` (
  `u_id` int(11) NOT NULL,
  `u_name` varchar(255) DEFAULT NULL,
  `u_email` varchar(255) DEFAULT NULL,
  `nid` varchar(255) DEFAULT NULL,
  `u_phoneno` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `u_type` varchar(255) DEFAULT NULL,
  `u_pic` blob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usr`
--

INSERT INTO `usr` (`u_id`, `u_name`, `u_email`, `nid`, `u_phoneno`, `username`, `password`, `u_type`, `u_pic`) VALUES
(1, 'A', 'as@gamil.com', '2314234', '3424234', 'az', '123', 'admin', ''),
(2, 'f2343', 'as@gamil.com', '2314234', '3424234', 'qw', '123', 'customer', ''),
(4, 'erwer', 'as@gamil.com', 'ewrwr', '3424234', 'azz', '12345', 'customer', 0x50696e7943726561746f72735f3633373334303038323937393539383432312e6a7067),
(5, 'fdxgdfg', 'as@gamil.com', '2314234', '3424234', 'qazxcv', '123456', 'customer', 0x50696e7943726561746f72735f3633373334303038353131363535363033332e6a7067),
(6, 'a1', '2', '2', 'wqaeqeqweqe', '', '', '', 0x50696e7943726561746f72735f3633373334303038323937393539383432312e6a7067),
(7, 'a2', '1', '4', '11wqeqweqwe', '', '', '', 0x50696e7943726561746f72735f3633373334303038323937393539383432312e6a7067),
(8, 'f2123', 'as@gamil.com', '12', '3424234', '', '', '', 0x50696e7943726561746f72735f3633373334303038323937393539383432312e6a7067),
(9, '123', 'as@gamil.com', '1', '3424234', '', '', '', 0x50696e7943726561746f72735f3633373334303038353131363535363033332e6a7067),
(10, '', '', '', '', '', '', '', 0x50696e7943726561746f72735f3633373334303038323937393539383432312e6a7067);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `apartment`
--
ALTER TABLE `apartment`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `usr`
--
ALTER TABLE `usr`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `apartment`
--
ALTER TABLE `apartment`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `usr`
--
ALTER TABLE `usr`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
