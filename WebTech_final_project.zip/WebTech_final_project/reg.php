<?php

    include "includes/db_connect.inc.php";

    $uname = $uemail = $unid = $uphone = $uusername =$upassword = $uimg = $utype = $message = "";

    if($_SERVER["REQUEST_METHOD"] == "POST"){
	
        if(!empty($_POST['namee'])){
            $uname = mysqli_real_escape_string($conn, $_POST['namee']);
        }
        if(!empty($_POST['email'])){
            $uemail = mysqli_real_escape_string($conn, $_POST['email']);
        }
        if(!empty($_POST['nid'])){
            $unid = mysqli_real_escape_string($conn, $_POST['nid']);
        }
        if(!empty($_POST['phone'])){
            $uphone = mysqli_real_escape_string($conn, $_POST['phone']);
        }
        if(!empty($_POST['username'])){
            $uusername = mysqli_real_escape_string($conn, $_POST['username']);
        }
        if(!empty($_POST['password'])){
            $upassword = mysqli_real_escape_string($conn, $_POST['password']);
        }
        if(!empty($_POST['type'])){
            $utype = mysqli_real_escape_string($conn, $_POST['type']);
        }
        if(!empty($_POST['img'])){
            $uimg = mysqli_real_escape_string($conn, $_POST['img']);
            // $uimg = $_FILES['img']['tmp_name'];
        }
    
        $sqlUserCheck = "INSERT INTO usr(u_name, u_email, nid, u_phoneno, username, password, u_type, u_pic) VALUES('$uname' , '$uemail' , '$unid' , '$uphone' , '$uusername' ,'$upassword' , '$utype' , '$uimg')";
    
        if($result2 = mysqli_query($conn, $sqlUserCheck)){
            echo "<script>alert('Record Insert successfully')</script>";
            echo "<script>window.open('login.php','_self')</script>";
        }

        $conn->close();
    }

?>


<html>

<head>
    <link rel="stylesheet" href="css/account.css">
    <title>AddUser</title>
</head>

<body>
<Section class="main">
            <div class="logout">
				<a class="lg" href="account.php">Back</a>
				<a class="lg" href="logout.php">Logout</a>
			</div>
        </section>
    <div class="form">
        <style>
            .input1 {
                width: 200px;
                height: 40px;
                margin: 0 auto 0;
                margin-top: 10px;
                box-sizing: border-box;
            }
            
            .lbutton {
                background-color: skyblue;
                border: solid;
                color: blue;
                padding: 15px 60px;
                text-decoration: none;
                font-size: 16px;
                margin: 0 auto 0;
                margin-top: 10px;
                border-radius: 4px;
                border-color: gray;
            }
        </style>
        <form action="adduser.php" method="post">
            <h1 align="center"><u>Insert User</u></h1>
            <input type="text" Class="input1" name="namee" placeholder="Name" value="" required><br>
            <input type="Email" Class="input1" name="email" placeholder="Email" value="" required><br>
            <input type="text" Class="input1" name="nid" placeholder="NID" value="" required><br>
            <input type="text" Class="input1" name="phone" placeholder="PhoneNo." value="" required><br>
            <input type="text" Class="input1" name="username" placeholder="username" value="" required><br>
            <input type="password" Class="input1" name="password" placeholder="password" value="" required><br>
            <select Class="input1" name="type">
                        <option value="customer">Customer</option>
                    </select><br>
            <input type="file" Class="input1" name="img" accept="image/gif, image/jpeg, image/png"> <br>
            <button type="submit" name="insert" class="lbutton">Insert</button><br>
        </form>
    </div>
</body>

</html>