<?php

    include "includes/db_connect.inc.php";
    session_start();

    $uid = $uuid =$uname = $uemail = $unid = $uphone = $uusername =$upassword = $uimg = $utype = $message = "";
    // echo (isset($_GET['uuid']) ? $_GET['uuid'] : '');
    $uid = (isset($_GET['uuid']) ? $_GET['uuid'] : '');
    // $uid = intval(isset($_GET['uuid']) ? $_GET['uuid'] : '');
    $sql = "SELECT * FROM usr WHERE u_id = '$uid'";
    $result = mysqli_query($conn, $sql);
    $rowCount = mysqli_num_rows($result);
    while($row = mysqli_fetch_assoc($result)){
        $uuid = $row['u_id'];
        $uname = $row['u_name'];
        $uemail = $row['u_email'];
        $unid = $row['nid'];
        $uphone = $row['u_phoneno'];
        $uusername = $row['username'];
        $upassword = $row['password'];
        $utype = $row['u_type'];
        $uimg = $row['u_pic'];
    }
    

    if($_SERVER["REQUEST_METHOD"] == "POST"){
	
        if(!empty($_POST['id'])){
            $uuid = mysqli_real_escape_string($conn, $_POST['id']);
        }
        if(!empty($_POST['namee'])){
            $uname = mysqli_real_escape_string($conn, $_POST['namee']);
        }
        if(!empty($_POST['email'])){
            $uemail = mysqli_real_escape_string($conn, $_POST['email']);
        }
        if(!empty($_POST['nid'])){
            $unid = mysqli_real_escape_string($conn, $_POST['nid']);
        }
        if(!empty($_POST['phone'])){
            $uphone = mysqli_real_escape_string($conn, $_POST['phone']);
        }
        if(!empty($_POST['username'])){
            $uusername = mysqli_real_escape_string($conn, $_POST['username']);
        }
        if(!empty($_POST['password'])){
            $upassword = mysqli_real_escape_string($conn, $_POST['password']);
        }
        if(!empty($_POST['type'])){
            $utype = mysqli_real_escape_string($conn, $_POST['type']);
        }
        if(!empty($_POST['img'])){
            $uimg = mysqli_real_escape_string($conn, $_POST['img']);
        }
        $sqlUserCheck = "UPDATE usr SET u_name='$uname', u_email='$uemail', nid='$unid', u_phoneno='$uphone', username='$uusername', password='$upassword', u_type='$utype', u_pic='$uimg' WHERE u_id='$uuid'";
    
        if ($conn->query($sqlUserCheck) === TRUE) {
            echo "<script>alert('Record updated successfully')</script>";
            echo "<script>window.open('account.php','_self')</script>";
          }
          else{
              echo $conn->error;
          }

        $conn->close();
    }

?>


<html>

<head>
    <link rel="stylesheet" href="css/account.css">
    <title>AddUser</title>
    <!-- <script>
        function testJS(){
        var b = document.getElementById('uid').value
        document.getElementById('name').innerHTML = b;
        }
    </script> -->
</head>

<body>
<Section class="main">
            <div class="logout">
				<a class="lg" href="account.php">Back</a>
				<a class="lg" href="logout.php">Logout</a>
			</div>
        </section>
    <div class="form">
        <style>
            .input1 {
                width: 200px;
                height: 40px;
                margin: 0 auto 0;
                margin-top: 10px;
                box-sizing: border-box;
            }
            
            .lbutton {
                background-color: skyblue;
                border: solid;
                color: blue;
                padding: 15px 60px;
                text-decoration: none;
                font-size: 16px;
                margin: 0 auto 0;
                margin-top: 10px;
                border-radius: 4px;
                border-color: gray;
            }
        </style>
        <form action="updateuser.php" method="post">
            <h1 align="center"><u>Update User</u></h1>
            <input type="text" Class="input1" id="name" name="id" placeholder="ID" value="<?php echo $uuid ?>" required readonly><br>
            <input type="text" Class="input1" id="name" name="namee" placeholder="Name" value="<?php echo $uname ?>" required><br>
            <input type="Email" Class="input1" name="email" placeholder="Email" value="<?php echo $uemail ?>" required><br>
            <input type="text" Class="input1" name="nid" placeholder="NID" value="<?php echo $unid ?>" required><br>
            <input type="text" Class="input1" name="phone" placeholder="PhoneNo." value="<?php echo $uphone ?>" required><br>
            <input type="text" Class="input1" name="username" placeholder="username" value="<?php echo $uusername ?>" required><br>
            <input type="password" Class="input1" name="password" placeholder="password" value="<?php echo $upassword ?>" required><br>
            
            <select Class="input1" name="type" value="<?php echo $u_type ?>">
                <option value="admin">Admin</option>
                <option value="customer">Customer</option>
            </select><br>
            <div class="dp">
                <img src="data:image/jpeg;base64,<?php echo base64_encode($uimg) ; ?>" style="width:150px">
            </div>
            <input type="file" Class="input1" name="img" accept="image/gif, image/jpeg, image/png"> <br>
            <button type="submit" name="insert" class="lbutton">Update</button><br>
        </form>
    </div>
</body>

</html>