
<?php 
include "includes/db_connect.inc.php";
session_start();
$uPass = $uName = $message = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){

	if(!empty($_POST['username'])){
		$uName = mysqli_real_escape_string($conn, $_POST['username']);
	}
	if(!empty($_POST['password'])){
		$uPass = mysqli_real_escape_string($conn, $_POST['password']);
	}

	$sqlUserCheck = "SELECT u_name, password, u_type FROM usr WHERE username = '$uName'";
	$result = mysqli_query($conn, $sqlUserCheck);
	$rowCount = mysqli_num_rows($result);

	if($rowCount < 1){
		$message = "User does not exist!";
	}
	else{
		while($row = mysqli_fetch_assoc($result)){
			$uPassInDB = $row['password'];
			$utypeDB = $row['u_type'];

			if($uPass==$uPassInDB){
				if($utypeDB=="admin"){
					$_SESSION['username'] = $uName;
					header("Location: account.php");
				}
				else{
					header("Location: index.html");
				}
			}
			else{
				$message = "Wrong Password!";
			}
		}
	}
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration system PHP and MySQL</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	
</head>
<header>
	<div class="menu">
		<!-- Start Brand name coding-->
		<div class="brand-name">
			<a href="index.html">
				<h2 class="animated flash">
				<i class="fa fa-apartment"></i>&nbsp;
				APARTMENT SEQURITY.COM</h2>
			</a>
		</div>
		<!-- End Brand name coding-->
		<!-- Start Nav coding & menu coding -->
         <nav>
         	<ul>
         		<li><a href="index.html">Home</a></li>
         		
         		
         		<li><a href="index.php">Log Out</a></li>
         		<li><a href="contact.html">Contact Us</a></li>
         	</ul>
         </nav>
		<!-- End Nav coding & menu coding -->
	</div>
</header>

<body>

	<div class="header">
		<h2>Login</h2>
	</div>
	
	<form method="post" action="login.php">

		<div class="input-group">
			<label>Username</label>
			<input type="text" name="username" >
		</div>
		<div class="input-group">
			<label>Password</label>
			<input type="password" name="password">
		</div>
		<div class="input-group">
			<button type="submit" class="btn" name="login_user">Login</button>
		</div>
		<p>
			Not yet a member? <a href="reg.php">Sign up</a>
		</p>
	</form>


</body>
</html>