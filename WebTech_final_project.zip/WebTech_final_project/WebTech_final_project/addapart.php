<?php

    include "includes/db_connect.inc.php";
    session_start();

    $ano = $fno = $nr = $dicp = $img = $message = "";

    if($_SERVER["REQUEST_METHOD"] == "POST"){
	
        if(!empty($_POST['ano'])){
            $ano = mysqli_real_escape_string($conn, $_POST['ano']);
        }
        if(!empty($_POST['fno'])){
            $fno = mysqli_real_escape_string($conn, $_POST['fno']);
        }
        if(!empty($_POST['nr'])){
            $nr = mysqli_real_escape_string($conn, $_POST['nr']);
        }
        if(!empty($_POST['dicp'])){
            $dicp = mysqli_real_escape_string($conn, $_POST['dicp']);
        }
        if(!empty($_POST['img'])){
            $img = mysqli_real_escape_string($conn, $_POST['img']);
            // $uimg = $_FILES['img']['tmp_name'];
        }
    
        $sqlUserCheck = "INSERT INTO apartment(a_no, floor_no, no_of_room, description, a_pic) VALUES('$ano' , '$fno' , '$nr' , '$dicp' , '$img')";
    
        if($result2 = mysqli_query($conn, $sqlUserCheck)){
            echo "<script>alert('Record Insert successfully')</script>";
            echo "<script>window.open('account.php','_self')</script>";
        }

        $conn->close();
    }

?>


<html>

<head>
    <link rel="stylesheet" href="css/account.css">
    <title>AddUser</title>
</head>

<body>
<Section class="main">
            <div class="logout">
				<a class="lg" href="account.php">Back</a>
				<a class="lg" href="logout.php">Logout</a>
			</div>
        </section>
    <div class="form">
        <style>
            .input1 {
                width: 200px;
                height: 40px;
                margin: 0 auto 0;
                margin-top: 10px;
                box-sizing: border-box;
            }
            
            .lbutton {
                background-color: skyblue;
                border: solid;
                color: blue;
                padding: 15px 60px;
                text-decoration: none;
                font-size: 16px;
                margin: 0 auto 0;
                margin-top: 10px;
                border-radius: 4px;
                border-color: gray;
            }
        </style>
        <form action="addapart.php" method="post">
            <h1 align="center"><u>Insert Appartment</u></h1>
            <input type="text" Class="input1" name="ano" placeholder="AppartmentsNo" value="" required><br>
            <input type="text" Class="input1" name="fno" placeholder="FloorNo" value="" required><br>
            <input type="number" Class="input1" name="nr" placeholder="Number Of Room" value="" required><br>
            <input type="text" Class="input1" name="dicp" placeholder="Description." value="" required><br>
            <input type="file" Class="input1" name="img" accept="image/gif, image/jpeg, image/png"> <br>
            <button type="submit" name="insert" class="lbutton">Insert</button><br>
        </form>
    </div>
</body>

</html>