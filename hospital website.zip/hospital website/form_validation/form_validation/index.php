<?php
	if(isset($_POST["register"])){
?>
	Name : <?php echo $_POST["name"];?> <br>
	Username:  <?php echo $_POST["uname"];?> <br>
	Password:  <?php echo $_POST["pass"];?> <br>
	Gender:  <?php echo $_POST["gndr"];?> <br>
	Profession:  <?php echo $_POST["profs"];?> <br>
	Bio:  <?php echo $_POST["bio"];?> <br>
	Hobbies:
	<ul>
		<?php
			foreach($_POST["hobbies"] as $hobby)
			{
				echo "<li>$hobby</li>";
			}
		?>
	</ul>

	<?php }
		else{
	?>
<html>
	<head>
		<title>Registration</title>
	</head>
	<body>
		<h1>Registration Form</h1>
		<hr/>
		<form action="" method="post">
			<table >
				<tr>
					<td>Name:</td>
					<td><input type="text"  name="name" ></td>
				</tr>
				<tr>
					<td>Username:</td>
					<td><input type="text"  name="uname" ></td>
				</tr>
				<tr>
					<td>Password:</td>
					<td><input type="password" name="pass"></td>
				</tr>
				<tr>
					<td>Gender:</td>
					<td><input type="radio" value="Male" name="gndr"> Male <input type="radio" value="Female" name="gndr"> Female</td>
				</tr>
				<tr>
					<td>Hobbies: </td>
					<td><input type="checkbox" value="Music" name="hobbies[]"> Music 
					<input type="checkbox" value="Movies" name="hobbies[]"> Movies 
					<input type="checkbox" value="Games" name="hobbies[]"> Games
					</td>
				</tr>
				<tr>
					<td>Profession:  </td>
					<td>
						<select name="profs">
							<option>Teacher</option>
							<option>Student</option>
							<option>Business</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>Bio: </td>
					<td><textarea name="bio"></textarea> </td>
				</tr>
				<tr>
					<td colspan="2" >
						<input type="submit" name="register" value="Register">
						<input type="button" value="Refresh"> 
					</td>
				</tr>
			</table>
			
			 
			
		</form>
	</body>
</html>
		<?php }?>