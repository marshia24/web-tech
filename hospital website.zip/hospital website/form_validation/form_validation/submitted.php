<html>
	<h1>Form Submitted</h1>
	Name : <?php echo $_POST["name"];?> <br>
	Username:  <?php echo $_POST["uname"];?> <br>
	Password:  <?php echo $_POST["pass"];?> <br>
	Gender:  <?php echo $_POST["gndr"];?> <br>
	Profession:  <?php echo $_POST["profs"];?> <br>
	Bio:  <?php echo $_POST["bio"];?> <br>
	Hobbies:
	<ul>
		<?php
			foreach($_POST["hobbies"] as $hobby)
			{
				echo "<li>$hobby</li>";
			}
		?>
	</ul>
	
</html>